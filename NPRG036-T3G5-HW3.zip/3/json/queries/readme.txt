query-1-1.jq: selects czech name of a town where a occcupant with firstName Michael lives.
query-1-2.jq: get names of mayors whose term has ended
query-1-3.jq: selects mayors and their addresses.
query-1-3.jq: get streets with sidewalk and count the number of occupants living on each of those streets
